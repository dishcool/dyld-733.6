/*	$KAME$	*/

/* to be nuked shortly */
#error "obsolete include file, include net/pfkeyv2.h instead"
