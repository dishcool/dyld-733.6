#include <darwintest.h>

T_DECL(sample_pass_test, "sample_pass_test") {
	T_PASS("sample pass test that passes");
}
