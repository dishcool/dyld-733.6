#ifndef UGH_LIBC_PRIVATE_H
#define UGH_LIBC_PRIVATE_H

#ifdef __cplusplus
extern "C"
#endif
void abort_report_np(const char*, ...);

#endif
