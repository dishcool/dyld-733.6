# dsc

"dsc" for "dyld shared cache".  
Invoke `build.sh` with path to dyld source folder, it'll build `dsc_closure`, `dsc_extractor` and `dsc_util` from source.
